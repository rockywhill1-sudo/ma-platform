# Session 2 — App Shell + Tenancy (Dev Mode, No Auth)

This package gets you from an empty Next.js project to a **fully navigable app with working multi-workspace tenancy**, auto-signed-in as your seed user. No login screen. RLS works correctly. Creating, switching, and deep-linking to workspaces all work.

## What's inside

```
supabase/migrations/
└── 01_tenancy.sql                        # One-time SQL: tables, RLS, seed user, seed company

src/
├── middleware.ts                         # Next.js middleware
├── lib/
│   ├── dev-auth.ts                       # ★ DEV STUB — remove to add real auth
│   ├── types.ts                          # Shared TypeScript types
│   ├── supabase/
│   │   ├── server.ts                     # Server-side Supabase client
│   │   ├── client.ts                     # Browser-side Supabase client
│   │   └── middleware.ts                 # ★ Contains dev-auth auto-login block
│   └── queries/
│       └── companies.ts                  # getCompanyById, getCompaniesForCurrentUser
├── components/
│   ├── app-shell.tsx                     # Sidebar + main content
│   ├── sidebar.tsx                       # Full sidebar with switcher + nav + user card
│   ├── company-switcher.tsx              # Dropdown at top of sidebar
│   ├── nav-item.tsx                      # Sidebar link w/ active state
│   ├── user-card.tsx                     # Bottom of sidebar + dev-mode banner
│   ├── page-header.tsx                   # Top bar for each page
│   ├── empty-state.tsx                   # Reusable empty state
│   └── create-company-dialog.tsx         # Modal form, full end-to-end
└── app/
    ├── layout.tsx                        # Root layout (Inter + JetBrains Mono)
    ├── globals.css                       # Design tokens from doc 03
    ├── page.tsx                          # → redirects to first company or /companies/new
    ├── actions/
    │   └── companies.ts                  # createCompany() server action
    └── companies/
        ├── new/page.tsx                  # Onboarding (no companies → land here)
        └── [companyId]/
            ├── layout.tsx                # Fetches data, wraps in AppShell
            ├── dashboard/page.tsx
            ├── financials/page.tsx
            ├── analytics/page.tsx
            ├── signals/page.tsx
            ├── valuation/page.tsx
            ├── checklists/page.tsx
            ├── reports/page.tsx
            ├── integrations/page.tsx     # Lists 5 connectors as cards
            └── admin/page.tsx            # Real data — workspace details + member list
```

---

## Setup runbook (10–15 minutes, first time)

### 1. Prerequisites

If you haven't already, scaffold the Next.js app and install shadcn:

```bash
pnpm create cloudflare@latest web --framework=next --platform=workers
cd web
pnpm add @supabase/supabase-js @supabase/ssr zod
pnpm dlx shadcn@latest init -d
pnpm dlx shadcn@latest add button input label card sonner dialog dropdown-menu avatar
```

> **Important:** this session uses `dialog`, `dropdown-menu`, and `avatar` — three components beyond the Day 1 starter. Don't skip the `shadcn add` line above.

### 2. Overlay this starter

From the tarball location:

```bash
cd web
tar -xzf ../ma-platform-app.tar.gz --strip-components=1 --overwrite
```

This drops in the SQL migration under `supabase/migrations/` and all source files under `src/`.

### 3. Environment variables

```bash
cp .env.local.example .env.local   # if you haven't already
```

Paste your Supabase project URL and anon key from **Supabase Dashboard → Settings → API**. The anon key is the one labeled `anon public`. You do **not** need the service role key for this session — migrations run via SQL Editor, app auth runs through the anon key.

### 4. Run the SQL migration

Open **Supabase Dashboard → SQL Editor → New query**. Copy the entire contents of `supabase/migrations/01_tenancy.sql`, paste, and click **Run**.

You should see a clean "Success. No rows returned." at the bottom.

Verify the seed worked:

```sql
select id, name, slug from public.companies;
select * from public.company_users;
select id, email from auth.users where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
```

All three should return one row.

### 5. Configure Supabase Auth redirect URL

**Supabase Dashboard → Authentication → URL Configuration → Site URL:** set to `http://localhost:3000`. (Even with dev auth, Supabase validates this for session cookies.)

### 6. Start the dev server

```bash
pnpm dev
```

Open http://localhost:3000. You should see:

1. Brief blank page (middleware is auto-signing you in)
2. Immediate redirect to `/companies/cccc.../dashboard`
3. **NeuralEdge AI Group** dashboard with sidebar and empty state

### 7. Try the flows

- **Create a new workspace.** Click the dropdown at the top of the sidebar → "New workspace" → fill in a name → Create. You should land on the new workspace's dashboard.
- **Switch between workspaces.** Open the same dropdown; all your workspaces are listed with a checkmark next to the active one.
- **Deep link.** Copy `/companies/<id>/signals` from the URL, paste into a new tab. No login screen; you land directly on the page.
- **Admin page.** Go to Admin — you'll see the real workspace metadata and your membership with role = `owner`.

---

## How the dev-auth stub works

Two files own the cheat:

1. `src/lib/dev-auth.ts` — constants (email, password, UUID)
2. `src/lib/supabase/middleware.ts` — the auto-login block, clearly bracketed by `=== DEV AUTH ===` / `=== END DEV AUTH ===`

The flow on a fresh browser (no cookies):

```
Browser → GET /                    (no session cookie)
Middleware → supabase.auth.getUser()  → null
Middleware → signInWithPassword(seedEmail, seedPassword)
Middleware → sets cookies, responds with 307 redirect to /
Browser → GET / with cookies       (session now valid)
Middleware → getUser() returns Rocky
Root page → redirects to /companies/.../dashboard
```

After the first round trip the session persists like any normal Supabase session. No further auto-logins until cookies expire.

### Removing dev auth (when you add real auth)

1. Delete `src/lib/dev-auth.ts`
2. In `src/lib/supabase/middleware.ts`, delete everything between `=== DEV AUTH ===` and `=== END DEV AUTH ===`
3. Add back a real login page (the Day 1 starter has one you can revive)
4. Update Supabase → Auth → Users → change the seed user's password or delete it entirely
5. Verify: start in incognito → visit `/` → should redirect to `/login`, not auto-sign-in

---

## What's working end-to-end right now

- ✅ Multi-tenant schema with RLS enforced by `auth.uid()`
- ✅ Seed user + seed company with owner membership
- ✅ Dev auto-login (no login screen, real session)
- ✅ Sidebar with company switcher, 9 nav items, user card
- ✅ Create new workspace via modal (full round trip: INSERT company → INSERT membership → navigate into it)
- ✅ All 9 pages render as real routes with on-brand empty states
- ✅ Admin page shows real workspace data and real member list (not stubbed)

## What's deliberately not built yet

These are the empty-state targets — each ships in a later session:
- Phase 04: QBO OAuth + other integrations
- Phase 05: Normalization engine
- Phase 06: Analytics + Signals
- Phase 08: Valuation engine
- Phase 09: Checklists + templates
- Phase 10: PDF reports via Browser Run
- Invite new members by email
- Real authentication (dev stub in place until then)

---

## Troubleshooting

**"signIn failed: Invalid login credentials" in terminal.**
The SQL migration didn't run, or it ran but the seed user didn't insert. Re-run `01_tenancy.sql` and check `select * from auth.users;` for the seed UUID.

**Browser gets stuck in redirect loop.**
The middleware tried to sign in and failed, but didn't log the error clearly. Check the terminal where `pnpm dev` is running. Most common cause: wrong `NEXT_PUBLIC_SUPABASE_URL` or `NEXT_PUBLIC_SUPABASE_ANON_KEY` in `.env.local`.

**Page renders but sidebar shows "User" instead of "Rocky Hill".**
The `on_auth_user_created` trigger didn't fire (user was inserted before it existed). Run this once to backfill:
```sql
insert into public.user_profiles (id, email, full_name)
select id, email, coalesce(raw_user_meta_data->>'full_name', split_part(email, '@', 1))
from auth.users
on conflict (id) do nothing;
```

**Creating a second workspace fails with "permission denied for table company_users".**
An earlier version of the RLS policies had a bug. Re-run `01_tenancy.sql` — it's idempotent and will update the policies.

---

## Next session

After you've got this running locally and clicked through every page, the next thing to tackle is **Phase 04 — QuickBooks integration**: OAuth flow, token storage (encrypted via `pgsodium`), first raw-data sync, and the Integrations page comes alive.
