-- =============================================================================
-- 01 — TENANCY LAYER + SEED
-- Paste this file into Supabase SQL Editor and hit Run.
-- Idempotent: safe to re-run.
-- =============================================================================

begin;

-- -----------------------------------------------------------------------------
-- Extensions
-- -----------------------------------------------------------------------------
create extension if not exists pgcrypto;
create extension if not exists citext;

-- -----------------------------------------------------------------------------
-- Enums
-- -----------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_type where typname = 'company_role') then
    create type public.company_role as enum ('owner', 'analyst', 'viewer');
  end if;
end$$;

-- -----------------------------------------------------------------------------
-- Helper: updated_at trigger function
-- -----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- -----------------------------------------------------------------------------
-- user_profiles — app-side mirror of auth.users
-- -----------------------------------------------------------------------------
create table if not exists public.user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email citext not null unique,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_user_profiles_updated_at on public.user_profiles;
create trigger trg_user_profiles_updated_at
  before update on public.user_profiles
  for each row execute function public.set_updated_at();

-- Auto-create a profile row whenever a new auth.users row appears
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.user_profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- -----------------------------------------------------------------------------
-- companies — top-level tenant
-- -----------------------------------------------------------------------------
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  industry text,
  hq_country text default 'US',
  fiscal_year_end_month int default 12 check (fiscal_year_end_month between 1 and 12),
  currency text not null default 'USD',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists idx_companies_deleted_at on public.companies(deleted_at) where deleted_at is null;

drop trigger if exists trg_companies_updated_at on public.companies;
create trigger trg_companies_updated_at
  before update on public.companies
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- company_users — membership + role
-- -----------------------------------------------------------------------------
create table if not exists public.company_users (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.company_role not null default 'viewer',
  added_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key (company_id, user_id)
);

create index if not exists idx_company_users_user_id on public.company_users(user_id);

-- -----------------------------------------------------------------------------
-- company_invites — pending email-based invites
-- -----------------------------------------------------------------------------
create table if not exists public.company_invites (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email citext not null,
  role public.company_role not null default 'viewer',
  token text not null unique default encode(gen_random_bytes(32), 'hex'),
  invited_by uuid references auth.users(id) on delete set null,
  expires_at timestamptz not null default (now() + interval '7 days'),
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  unique (company_id, email)
);

-- -----------------------------------------------------------------------------
-- RLS helper functions
-- -----------------------------------------------------------------------------
create or replace function public.is_company_member(p_company_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.company_users
    where company_id = p_company_id
      and user_id = auth.uid()
  );
$$;

create or replace function public.company_role(p_company_id uuid)
returns public.company_role
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.company_users
  where company_id = p_company_id
    and user_id = auth.uid()
  limit 1;
$$;

create or replace function public.can_write(p_company_id uuid)
returns boolean
language sql
stable
as $$
  select public.company_role(p_company_id) in ('owner', 'analyst');
$$;

create or replace function public.can_admin(p_company_id uuid)
returns boolean
language sql
stable
as $$
  select public.company_role(p_company_id) = 'owner';
$$;

-- -----------------------------------------------------------------------------
-- RLS policies
-- -----------------------------------------------------------------------------
alter table public.user_profiles    enable row level security;
alter table public.companies        enable row level security;
alter table public.company_users    enable row level security;
alter table public.company_invites  enable row level security;

-- user_profiles: users can read/update their own profile, and read profiles of
-- people they share a company with (for @-mentions, activity feeds, etc).
drop policy if exists up_select_self on public.user_profiles;
create policy up_select_self on public.user_profiles
  for select using (id = auth.uid());

drop policy if exists up_select_shared_company on public.user_profiles;
create policy up_select_shared_company on public.user_profiles
  for select using (
    exists (
      select 1 from public.company_users a
      join public.company_users b on a.company_id = b.company_id
      where a.user_id = auth.uid() and b.user_id = public.user_profiles.id
    )
  );

drop policy if exists up_update_self on public.user_profiles;
create policy up_update_self on public.user_profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- companies: any member can read; any authenticated user can create;
-- only owners can update or soft-delete.
drop policy if exists co_select_member on public.companies;
create policy co_select_member on public.companies
  for select using (public.is_company_member(id) and deleted_at is null);

drop policy if exists co_insert_any on public.companies;
create policy co_insert_any on public.companies
  for insert with check (auth.uid() is not null);

drop policy if exists co_update_admin on public.companies;
create policy co_update_admin on public.companies
  for update using (public.can_admin(id));

-- company_users: members can read the membership list of their own companies;
-- only owners can add/remove/change roles.
drop policy if exists cu_select_member on public.company_users;
create policy cu_select_member on public.company_users
  for select using (public.is_company_member(company_id));

drop policy if exists cu_insert_admin on public.company_users;
create policy cu_insert_admin on public.company_users
  for insert with check (
    -- Owner of the company OR creating first owner row (bootstrap)
    public.can_admin(company_id)
    or (
      user_id = auth.uid()
      and not exists (select 1 from public.company_users where company_id = company_users.company_id)
    )
  );

drop policy if exists cu_update_admin on public.company_users;
create policy cu_update_admin on public.company_users
  for update using (public.can_admin(company_id));

drop policy if exists cu_delete_admin on public.company_users;
create policy cu_delete_admin on public.company_users
  for delete using (public.can_admin(company_id));

-- company_invites: admins only.
drop policy if exists ci_select_admin on public.company_invites;
create policy ci_select_admin on public.company_invites
  for select using (public.can_admin(company_id));

drop policy if exists ci_insert_admin on public.company_invites;
create policy ci_insert_admin on public.company_invites
  for insert with check (public.can_admin(company_id));

drop policy if exists ci_update_admin on public.company_invites;
create policy ci_update_admin on public.company_invites
  for update using (public.can_admin(company_id));

drop policy if exists ci_delete_admin on public.company_invites;
create policy ci_delete_admin on public.company_invites
  for delete using (public.can_admin(company_id));


-- =============================================================================
-- SEED — dev user + NeuralEdge AI Group
-- These UUIDs are deterministic so the app can reference them.
-- =============================================================================

-- Seed auth user
do $$
declare
  v_user_id uuid := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
  v_email text := 'rocky.hill@almcoe.online';
  v_password text := 'devpassword_change_before_production';
begin
  if not exists (select 1 from auth.users where id = v_user_id) then
    insert into auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at,
      confirmation_token, email_change, email_change_token_new, recovery_token
    ) values (
      '00000000-0000-0000-0000-000000000000',
      v_user_id,
      'authenticated',
      'authenticated',
      v_email,
      crypt(v_password, gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Rocky Hill"}',
      now(), now(),
      '', '', '', ''
    );

    insert into auth.identities (
      id, user_id, identity_data, provider, provider_id,
      last_sign_in_at, created_at, updated_at
    ) values (
      gen_random_uuid(),
      v_user_id,
      jsonb_build_object('sub', v_user_id::text, 'email', v_email),
      'email',
      v_email,
      now(), now(), now()
    );
  end if;
end$$;

-- Seed profile (trigger should have created it, but make sure)
insert into public.user_profiles (id, email, full_name)
values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'rocky.hill@almcoe.online', 'Rocky Hill')
on conflict (id) do update set full_name = excluded.full_name;

-- Seed company: NeuralEdge AI Group
insert into public.companies (
  id, name, slug, industry, fiscal_year_end_month, currency, created_by
)
values (
  'cccccccc-cccc-cccc-cccc-cccccccccccc',
  'NeuralEdge AI Group',
  'neuraledge-ai-group',
  'Software & AI',
  12,
  'USD',
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
)
on conflict (id) do nothing;

-- Seed ownership: Rocky is owner of NeuralEdge
insert into public.company_users (company_id, user_id, role, added_by)
values (
  'cccccccc-cccc-cccc-cccc-cccccccccccc',
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  'owner',
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
)
on conflict (company_id, user_id) do update set role = excluded.role;

commit;

-- =============================================================================
-- DONE. Verify with:
--   select id, name, slug from public.companies;
--   select * from public.company_users;
--   select id, email from auth.users where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
-- =============================================================================
