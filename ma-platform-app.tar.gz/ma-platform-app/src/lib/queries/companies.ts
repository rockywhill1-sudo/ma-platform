import { createClient } from '@/lib/supabase/server'
import type { Company, CompanySummary } from '@/lib/types'

export async function getCompaniesForCurrentUser(): Promise<CompanySummary[]> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('companies')
    .select('id, name, slug, industry')
    .order('name', { ascending: true })

  if (error) {
    console.error('[getCompaniesForCurrentUser]', error.message)
    return []
  }
  return data ?? []
}

export async function getCompanyById(id: string): Promise<Company | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('companies')
    .select('*')
    .eq('id', id)
    .is('deleted_at', null)
    .single()

  if (error) return null
  return data as Company
}
