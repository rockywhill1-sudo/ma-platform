import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
import { DEV_USER_EMAIL, DEV_USER_PASSWORD } from '@/lib/dev-auth'

/**
 * Refreshes the Supabase auth session on every request.
 * Includes a DEV-ONLY auto-login block (clearly marked) so the app
 * is usable without a login screen during development.
 */
export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          )
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options),
          )
        },
      },
    },
  )

  const {
    data: { user },
  } = await supabase.auth.getUser()

  // =========================================================================
  // === DEV AUTH — REMOVE BEFORE PRODUCTION =================================
  // Auto-logs-in as the seed user so we don't have a login screen during
  // development. The session is real and RLS works correctly.
  if (!user) {
    const { error } = await supabase.auth.signInWithPassword({
      email: DEV_USER_EMAIL,
      password: DEV_USER_PASSWORD,
    })

    if (error) {
      console.error('[dev-auth] signIn failed:', error.message)
      console.error('[dev-auth] Did you run supabase/migrations/01_tenancy.sql?')
    } else {
      // Session cookies are now set on supabaseResponse via setAll.
      // Redirect to the same URL so the browser reloads with cookies,
      // guaranteeing the page component sees the session.
      const redirect = NextResponse.redirect(request.nextUrl)
      supabaseResponse.cookies.getAll().forEach((c) => {
        redirect.cookies.set({
          name: c.name,
          value: c.value,
          path: c.path,
          domain: c.domain,
          maxAge: c.maxAge,
          expires: c.expires,
          httpOnly: c.httpOnly,
          secure: c.secure,
          sameSite: c.sameSite as 'lax' | 'strict' | 'none' | undefined,
        })
      })
      return redirect
    }
  }
  // === END DEV AUTH =========================================================
  // =========================================================================

  return supabaseResponse
}
