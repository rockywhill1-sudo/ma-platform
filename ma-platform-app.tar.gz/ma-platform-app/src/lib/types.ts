export type CompanyRole = 'owner' | 'analyst' | 'viewer'

export type Company = {
  id: string
  name: string
  slug: string
  industry: string | null
  hq_country: string | null
  fiscal_year_end_month: number
  currency: string
  created_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
}

export type CompanySummary = Pick<Company, 'id' | 'name' | 'slug' | 'industry'>

export type NavKey =
  | 'dashboard'
  | 'financials'
  | 'analytics'
  | 'signals'
  | 'valuation'
  | 'checklists'
  | 'reports'
  | 'integrations'
  | 'admin'
