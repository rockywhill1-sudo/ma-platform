// =============================================================================
// DEV-AUTH STUB — REMOVE BEFORE PRODUCTION
// -----------------------------------------------------------------------------
// This file (and its usage in src/lib/supabase/middleware.ts) is the only
// place we cheat on authentication. When you're ready to ship real auth:
//
//   1. Delete this file.
//   2. Delete the `=== DEV AUTH ===` block in src/lib/supabase/middleware.ts.
//   3. Restore the login/signup pages from the Day 1 starter (or build your own).
//   4. Rotate the dev password in Supabase — this one is committed to the repo.
//
// The credentials below match the seed data in supabase/migrations/01_tenancy.sql.
// =============================================================================

export const DEV_USER_EMAIL = 'rocky.hill@almcoe.online'
export const DEV_USER_PASSWORD = 'devpassword_change_before_production'
export const DEV_USER_ID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
