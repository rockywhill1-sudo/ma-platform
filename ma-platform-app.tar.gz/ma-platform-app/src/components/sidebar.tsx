import {
  LayoutDashboard,
  BarChart3,
  TrendingUp,
  Activity,
  Calculator,
  ListChecks,
  FileText,
  Plug,
  Settings,
} from 'lucide-react'
import { CompanySwitcher } from './company-switcher'
import { NavItem } from './nav-item'
import { UserCard } from './user-card'
import type { CompanySummary } from '@/lib/types'

type Props = {
  currentCompany: CompanySummary
  companies: CompanySummary[]
  user: {
    fullName: string
    email: string
  }
}

export function Sidebar({ currentCompany, companies, user }: Props) {
  const base = `/companies/${currentCompany.id}`
  const sections: {
    label?: string
    items: { href: string; icon: typeof LayoutDashboard; label: string }[]
  }[] = [
    {
      items: [
        { href: `${base}/dashboard`, icon: LayoutDashboard, label: 'Dashboard' },
      ],
    },
    {
      label: 'Financial',
      items: [
        { href: `${base}/financials`, icon: BarChart3, label: 'Financials' },
        { href: `${base}/analytics`, icon: TrendingUp, label: 'Analytics' },
        { href: `${base}/signals`, icon: Activity, label: 'Signals' },
        { href: `${base}/valuation`, icon: Calculator, label: 'Valuation' },
      ],
    },
    {
      label: 'Deal',
      items: [
        { href: `${base}/checklists`, icon: ListChecks, label: 'Checklists' },
        { href: `${base}/reports`, icon: FileText, label: 'Reports' },
      ],
    },
    {
      label: 'Workspace',
      items: [
        { href: `${base}/integrations`, icon: Plug, label: 'Integrations' },
        { href: `${base}/admin`, icon: Settings, label: 'Admin' },
      ],
    },
  ]

  return (
    <aside className="w-60 border-r bg-background flex flex-col h-screen sticky top-0">
      {/* Company switcher */}
      <div className="p-3 border-b">
        <CompanySwitcher
          currentCompany={currentCompany}
          companies={companies}
        />
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
        {sections.map((section, i) => (
          <div key={i} className="space-y-1">
            {section.label && (
              <p className="px-2 text-[10px] font-mono tracking-widest uppercase text-muted-foreground mb-1.5">
                {section.label}
              </p>
            )}
            {section.items.map((item) => (
              <NavItem key={item.href} {...item} />
            ))}
          </div>
        ))}
      </nav>

      {/* User */}
      <div className="p-3 border-t">
        <UserCard fullName={user.fullName} email={user.email} />
      </div>
    </aside>
  )
}
