import { type ReactNode } from 'react'
import { Sidebar } from './sidebar'
import type { CompanySummary } from '@/lib/types'

type Props = {
  currentCompany: CompanySummary
  companies: CompanySummary[]
  user: {
    fullName: string
    email: string
  }
  children: ReactNode
}

export function AppShell({
  currentCompany,
  companies,
  user,
  children,
}: Props) {
  return (
    <div className="flex min-h-screen bg-muted/30">
      <Sidebar
        currentCompany={currentCompany}
        companies={companies}
        user={user}
      />
      <main className="flex-1 min-w-0 flex flex-col">{children}</main>
    </div>
  )
}
