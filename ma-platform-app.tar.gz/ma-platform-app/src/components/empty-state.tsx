import { type ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export type EmptyStateProps = {
  icon?: ReactNode
  eyebrow?: string
  title: string
  description: string
  primaryAction?: {
    label: string
    href?: string
    disabled?: boolean
    disabledHint?: string
  }
  secondaryAction?: {
    label: string
    href: string
  }
  children?: ReactNode
}

export function EmptyState({
  icon,
  eyebrow,
  title,
  description,
  primaryAction,
  secondaryAction,
  children,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-24 px-6 text-center">
      <div className="max-w-md space-y-6">
        {icon && (
          <div className="mx-auto h-12 w-12 rounded-md bg-primary/10 text-primary flex items-center justify-center">
            {icon}
          </div>
        )}
        <div className="space-y-2">
          {eyebrow && (
            <p className="text-xs font-mono tracking-widest uppercase text-muted-foreground">
              {eyebrow}
            </p>
          )}
          <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {description}
          </p>
        </div>

        {(primaryAction || secondaryAction) && (
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-center">
            {primaryAction && (
              <div className="flex flex-col items-center gap-1.5">
                {primaryAction.href && !primaryAction.disabled ? (
                  <Button asChild>
                    <Link href={primaryAction.href}>{primaryAction.label}</Link>
                  </Button>
                ) : (
                  <Button disabled={primaryAction.disabled}>
                    {primaryAction.label}
                  </Button>
                )}
                {primaryAction.disabledHint && (
                  <span className="text-xs text-muted-foreground font-mono">
                    {primaryAction.disabledHint}
                  </span>
                )}
              </div>
            )}
            {secondaryAction && (
              <Button asChild variant="outline">
                <Link href={secondaryAction.href}>{secondaryAction.label}</Link>
              </Button>
            )}
          </div>
        )}

        {children}
      </div>
    </div>
  )
}
