'use client'

import { useActionState, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { createCompany, type CreateCompanyState } from '@/app/actions/companies'

type Props = {
  trigger: React.ReactNode
}

export function CreateCompanyDialog({ trigger }: Props) {
  const [open, setOpen] = useState(false)
  const [state, formAction, pending] = useActionState<CreateCompanyState, FormData>(
    createCompany,
    null,
  )

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>New company workspace</DialogTitle>
          <DialogDescription>
            One workspace per deal or acquisition target. You&apos;ll connect
            accounting, run diligence, and produce reports against it.
          </DialogDescription>
        </DialogHeader>

        <form action={formAction} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Company name</Label>
            <Input
              id="name"
              name="name"
              type="text"
              placeholder="Acme Industrial, Inc."
              required
              autoFocus
              disabled={pending}
            />
            {state?.fieldErrors?.name && (
              <p className="text-xs text-destructive">{state.fieldErrors.name}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="industry">Industry</Label>
            <Input
              id="industry"
              name="industry"
              type="text"
              placeholder="Software, HVAC, Manufacturing..."
              disabled={pending}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="fiscalYearEndMonth">Fiscal year end</Label>
              <select
                id="fiscalYearEndMonth"
                name="fiscalYearEndMonth"
                defaultValue="12"
                disabled={pending}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
              >
                {[
                  [1, 'January'],
                  [2, 'February'],
                  [3, 'March'],
                  [4, 'April'],
                  [5, 'May'],
                  [6, 'June'],
                  [7, 'July'],
                  [8, 'August'],
                  [9, 'September'],
                  [10, 'October'],
                  [11, 'November'],
                  [12, 'December'],
                ].map(([m, label]) => (
                  <option key={m} value={m}>
                    {label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Input
                id="currency"
                name="currency"
                type="text"
                defaultValue="USD"
                maxLength={3}
                disabled={pending}
                className="font-mono uppercase"
              />
            </div>
          </div>

          {state?.error && (
            <p className="text-sm text-destructive font-medium" role="alert">
              {state.error}
            </p>
          )}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={pending}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? 'Creating…' : 'Create workspace'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
