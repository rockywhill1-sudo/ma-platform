import { Avatar, AvatarFallback } from '@/components/ui/avatar'

type Props = {
  fullName: string
  email: string
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('')
}

export function UserCard({ fullName, email }: Props) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2.5 px-2 py-2 rounded-md">
        <Avatar className="h-7 w-7">
          <AvatarFallback className="text-[11px] font-semibold bg-muted">
            {initials(fullName)}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium truncate leading-tight">{fullName}</p>
          <p className="text-[11px] text-muted-foreground truncate leading-tight font-mono">
            {email}
          </p>
        </div>
      </div>
      <div className="px-2 py-1.5 rounded-md bg-warning/10 border border-warning/20">
        <p className="text-[10px] font-mono uppercase tracking-widest text-warning-foreground/80 mb-0.5">
          Dev mode
        </p>
        <p className="text-[11px] text-muted-foreground leading-tight">
          Auto-login active. No real authentication.
        </p>
      </div>
    </div>
  )
}
