'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Check, ChevronsUpDown, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { CreateCompanyDialog } from './create-company-dialog'
import type { CompanySummary } from '@/lib/types'

type Props = {
  currentCompany: CompanySummary
  companies: CompanySummary[]
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('')
}

export function CompanySwitcher({ currentCompany, companies }: Props) {
  const router = useRouter()

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="w-full flex items-center gap-2.5 px-2 py-2 rounded-md hover:bg-muted transition-colors group text-left">
          <div className="h-7 w-7 rounded-md bg-primary text-primary-foreground grid place-items-center text-[11px] font-semibold tabular-nums flex-shrink-0">
            {initials(currentCompany.name)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold truncate leading-tight">
              {currentCompany.name}
            </p>
            {currentCompany.industry && (
              <p className="text-[11px] text-muted-foreground truncate leading-tight">
                {currentCompany.industry}
              </p>
            )}
          </div>
          <ChevronsUpDown className="h-4 w-4 text-muted-foreground group-hover:text-foreground flex-shrink-0" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64">
        <DropdownMenuLabel className="text-xs font-mono tracking-widest uppercase text-muted-foreground">
          Workspaces
        </DropdownMenuLabel>
        {companies.map((c) => (
          <DropdownMenuItem
            key={c.id}
            onClick={() => router.push(`/companies/${c.id}/dashboard`)}
            className="flex items-center gap-2.5 cursor-pointer"
          >
            <div className="h-6 w-6 rounded bg-muted grid place-items-center text-[10px] font-semibold flex-shrink-0">
              {initials(c.name)}
            </div>
            <span className="truncate flex-1">{c.name}</span>
            {c.id === currentCompany.id && (
              <Check className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            )}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <CreateCompanyDialog
          trigger={
            <DropdownMenuItem
              onSelect={(e) => e.preventDefault()}
              className="cursor-pointer text-muted-foreground"
            >
              <Plus className="h-4 w-4 mr-2" />
              New workspace
            </DropdownMenuItem>
          }
        />
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
