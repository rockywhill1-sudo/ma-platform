import { ListChecks } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'

export default async function ChecklistsPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  return (
    <>
      <PageHeader
        title="Checklists"
        description="Due diligence workflows across the M&A lifecycle — from LOI through close."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<ListChecks className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Phase 09"
          title="No checklists created yet"
          description="Pick from 7 stage templates — Sourcing, IOI, LOI, QoE, Legal Diligence, Financing, Close — or build your own. Every item supports assignment, due dates, file attachments, and activity threads."
          primaryAction={{
            label: 'Create from template',
            disabled: true,
            disabledHint: 'Available in phase 09',
          }}
        />
      </div>
    </>
  )
}
