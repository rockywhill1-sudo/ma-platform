import { Plug } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

type Integration = {
  key: string
  name: string
  description: string
  status: 'available' | 'coming-soon'
}

const INTEGRATIONS: Integration[] = [
  {
    key: 'quickbooks',
    name: 'QuickBooks Online',
    description: 'OAuth connection — pulls chart of accounts, GL, customers, vendors.',
    status: 'coming-soon',
  },
  {
    key: 'xero',
    name: 'Xero',
    description: 'OAuth connection — pulls chart of accounts, GL, contacts.',
    status: 'coming-soon',
  },
  {
    key: 'sage',
    name: 'Sage Intacct',
    description: 'API credentials — pulls normalized accounting data.',
    status: 'coming-soon',
  },
  {
    key: 'netsuite',
    name: 'NetSuite',
    description: 'SuiteCloud OAuth — pulls accounting and operational data.',
    status: 'coming-soon',
  },
  {
    key: 'csv',
    name: 'CSV upload',
    description: 'Upload trial balance, GL export, or normalized P&L/BS.',
    status: 'coming-soon',
  },
]

export default async function IntegrationsPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId: _companyId } = await params

  return (
    <>
      <PageHeader
        title="Integrations"
        description="Connect accounting systems or upload financials directly."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8 space-y-6">
        <div className="space-y-1">
          <p className="text-xs font-mono tracking-widest uppercase text-muted-foreground">
            Available connectors
          </p>
          <p className="text-sm text-muted-foreground">
            OAuth flows and API connections will ship in phase 04.
          </p>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          {INTEGRATIONS.map((integration) => (
            <Card key={integration.key} className="p-5 flex items-start gap-4">
              <div className="h-10 w-10 rounded-md bg-muted grid place-items-center flex-shrink-0 font-mono text-xs font-semibold tracking-widest">
                {integration.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0 space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium text-sm truncate">
                      {integration.name}
                    </h3>
                    <span className="text-[10px] font-mono tracking-widest uppercase text-muted-foreground px-1.5 py-0.5 rounded bg-muted">
                      Soon
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {integration.description}
                  </p>
                </div>
                <Button size="sm" variant="outline" disabled>
                  Connect
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </>
  )
}
