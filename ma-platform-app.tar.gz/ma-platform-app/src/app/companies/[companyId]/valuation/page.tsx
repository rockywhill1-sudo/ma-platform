import { Calculator } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'

export default async function ValuationPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  return (
    <>
      <PageHeader
        title="Valuation"
        description="EBITDA-multiple valuation, 5-year projections, and IRR sensitivity analysis."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<Calculator className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Phase 08"
          title="Valuation requires normalized financials"
          description="Once TTM EBITDA is computed from normalized periods, you can apply industry multiples, model 5-year projections with growth and margin assumptions, and run IRR sensitivity against entry multiple and exit timing."
          primaryAction={{
            label: 'Go to Integrations',
            href: `/companies/${companyId}/integrations`,
          }}
        />
      </div>
    </>
  )
}
