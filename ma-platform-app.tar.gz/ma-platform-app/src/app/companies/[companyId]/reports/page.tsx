import { FileText } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'

export default async function ReportsPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  return (
    <>
      <PageHeader
        title="Reports"
        description="Investor-grade PDFs — IOI, QoE, diligence summaries, and custom exports."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<FileText className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Phase 10"
          title="No reports generated yet"
          description="Reports are rendered by Cloudflare Browser Run and stored immutably in R2. Every report is a snapshot — the data it cites never changes, even as the underlying figures update. Presentation Mode produces a 16:9 slide deck in one click."
          primaryAction={{
            label: 'Generate IOI report',
            disabled: true,
            disabledHint: 'Available in phase 10',
          }}
        />
      </div>
    </>
  )
}
