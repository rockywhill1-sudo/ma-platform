import { Activity } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'

export default async function SignalsPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  return (
    <>
      <PageHeader
        title="Signals"
        description="Risk and opportunity indicators detected from financial and operational data."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<Activity className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Phase 06–07"
          title="No signals detected yet"
          description="The signals engine surfaces 12 categories — revenue concentration, margin compression, unusual GL activity, cash-conversion stress, vendor dependency, and more. Each signal is fingerprinted, severity-scored, and cites the underlying transactions."
          primaryAction={{
            label: 'Go to Integrations',
            href: `/companies/${companyId}/integrations`,
          }}
        />
      </div>
    </>
  )
}
