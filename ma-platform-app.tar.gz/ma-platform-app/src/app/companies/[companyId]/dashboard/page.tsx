import { LayoutDashboard } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'
import { getCompanyById } from '@/lib/queries/companies'

export default async function DashboardPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params
  const company = await getCompanyById(companyId)

  return (
    <>
      <PageHeader
        eyebrow={company?.name ?? 'Workspace'}
        title="Dashboard"
        description="High-level view of this workspace — KPIs, recent signals, and open diligence items."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<LayoutDashboard className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Empty workspace"
          title="Connect a data source to start"
          description="Once you connect an accounting system or upload financials, this dashboard will surface TTM revenue, EBITDA, top signals, and diligence progress at a glance."
          primaryAction={{
            label: 'Go to Integrations',
            href: `/companies/${companyId}/integrations`,
          }}
          secondaryAction={{
            label: 'View checklists',
            href: `/companies/${companyId}/checklists`,
          }}
        />
      </div>
    </>
  )
}
