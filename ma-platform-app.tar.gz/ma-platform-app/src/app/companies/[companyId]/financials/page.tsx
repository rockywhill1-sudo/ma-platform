import { BarChart3 } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'

export default async function FinancialsPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  return (
    <>
      <PageHeader
        title="Financials"
        description="P&L, Balance Sheet, and Cash Flow — normalized from your accounting system."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<BarChart3 className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Phase 04–05"
          title="No financials yet"
          description="Connect QuickBooks, Xero, Sage, or NetSuite to pull raw GL entries. Our normalization engine maps them to a standard chart of accounts for period-over-period comparisons."
          primaryAction={{
            label: 'Connect an accounting system',
            href: `/companies/${companyId}/integrations`,
          }}
        />
      </div>
    </>
  )
}
