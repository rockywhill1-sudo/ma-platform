import { TrendingUp } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { EmptyState } from '@/components/empty-state'

export default async function AnalyticsPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  return (
    <>
      <PageHeader
        title="Analytics"
        description="Trends, cohorts, margin analysis, and concentration — derived from normalized financials."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8">
        <EmptyState
          icon={<TrendingUp className="h-5 w-5" strokeWidth={1.75} />}
          eyebrow="Phase 06"
          title="Analytics come online with your first period"
          description="Revenue MoM/YoY/CAGR, gross-margin trend, customer concentration, vendor exposure, and working-capital dynamics — all computed automatically once financials land."
          primaryAction={{
            label: 'Go to Integrations',
            href: `/companies/${companyId}/integrations`,
          }}
        />
      </div>
    </>
  )
}
