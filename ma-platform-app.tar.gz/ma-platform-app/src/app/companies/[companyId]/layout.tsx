import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import {
  getCompaniesForCurrentUser,
  getCompanyById,
} from '@/lib/queries/companies'
import { AppShell } from '@/components/app-shell'

export default async function CompanyLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params

  const [company, companies, authResult] = await Promise.all([
    getCompanyById(companyId),
    getCompaniesForCurrentUser(),
    (async () => {
      const supabase = await createClient()
      return supabase.auth.getUser()
    })(),
  ])

  if (!company) notFound()

  const authUser = authResult.data.user
  if (!authUser) notFound()

  const supabase = await createClient()
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('full_name, email')
    .eq('id', authUser.id)
    .single()

  const user = {
    fullName: profile?.full_name ?? authUser.email?.split('@')[0] ?? 'User',
    email: profile?.email ?? authUser.email ?? '',
  }

  return (
    <AppShell currentCompany={company} companies={companies} user={user}>
      {children}
    </AppShell>
  )
}
