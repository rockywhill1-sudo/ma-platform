import { Settings } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { Card } from '@/components/ui/card'
import { getCompanyById } from '@/lib/queries/companies'
import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
]

export default async function AdminPage({
  params,
}: {
  params: Promise<{ companyId: string }>
}) {
  const { companyId } = await params
  const company = await getCompanyById(companyId)
  if (!company) notFound()

  const supabase = await createClient()
  const { data: members } = await supabase
    .from('company_users')
    .select('role, created_at, user_profiles(full_name, email)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: true })

  return (
    <>
      <PageHeader
        title="Admin"
        description="Workspace settings, members, and billing."
      />
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-6 lg:px-8 py-8 space-y-8">
        {/* Workspace details */}
        <section className="space-y-3">
          <p className="text-xs font-mono tracking-widest uppercase text-muted-foreground">
            Workspace
          </p>
          <Card className="p-6">
            <dl className="grid sm:grid-cols-2 gap-x-8 gap-y-4 text-sm">
              <div>
                <dt className="text-xs text-muted-foreground mb-1">Name</dt>
                <dd className="font-medium">{company.name}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground mb-1">Slug</dt>
                <dd className="font-mono text-xs">{company.slug}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground mb-1">Industry</dt>
                <dd className="font-medium">{company.industry ?? '—'}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground mb-1">Currency</dt>
                <dd className="font-mono tabular-nums">{company.currency}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground mb-1">
                  Fiscal year end
                </dt>
                <dd className="font-medium">
                  {MONTH_NAMES[company.fiscal_year_end_month - 1] ?? '—'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground mb-1">Created</dt>
                <dd className="font-mono tabular-nums text-xs">
                  {new Date(company.created_at).toLocaleDateString()}
                </dd>
              </div>
            </dl>
          </Card>
        </section>

        {/* Members */}
        <section className="space-y-3">
          <div className="flex items-baseline justify-between">
            <p className="text-xs font-mono tracking-widest uppercase text-muted-foreground">
              Members
            </p>
            <p className="text-xs text-muted-foreground">
              {members?.length ?? 0} total
            </p>
          </div>
          <Card className="divide-y divide-border">
            {members?.map((m, i) => {
              // Supabase types collapse the nested relation — cast narrowly.
              const profile = m.user_profiles as unknown as
                | { full_name: string | null; email: string }
                | null
              return (
                <div key={i} className="px-5 py-4 flex items-center gap-4">
                  <div className="h-8 w-8 rounded-full bg-muted grid place-items-center text-xs font-semibold">
                    {(profile?.full_name ?? profile?.email ?? '?')
                      .slice(0, 2)
                      .toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {profile?.full_name ?? '—'}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono truncate">
                      {profile?.email}
                    </p>
                  </div>
                  <span className="text-[10px] font-mono tracking-widest uppercase text-muted-foreground px-2 py-1 rounded bg-muted">
                    {m.role}
                  </span>
                </div>
              )
            })}
          </Card>
          <p className="text-xs text-muted-foreground">
            Inviting new members by email ships in phase 03.
          </p>
        </section>

        {/* Danger zone */}
        <section className="space-y-3">
          <p className="text-xs font-mono tracking-widest uppercase text-muted-foreground">
            Danger zone
          </p>
          <Card className="p-6 border-destructive/30">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Archive workspace</h3>
                <p className="text-xs text-muted-foreground leading-relaxed max-w-md">
                  Soft-deletes the workspace. Data is retained but hidden from
                  all members. Contact support to permanently delete.
                </p>
              </div>
              <button
                disabled
                className="text-xs font-medium px-3 py-1.5 rounded border border-destructive/30 text-destructive/60 cursor-not-allowed"
              >
                Archive
              </button>
            </div>
          </Card>
        </section>
      </div>
    </>
  )
}
