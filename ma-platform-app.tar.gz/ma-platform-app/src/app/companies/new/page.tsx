import { Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { CreateCompanyDialog } from '@/components/create-company-dialog'

export default function NewCompanyPage() {
  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left — brand */}
      <div className="hidden lg:flex flex-col justify-between bg-primary text-primary-foreground p-12">
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded-sm bg-primary-foreground/90" />
          <span className="font-semibold tracking-tight text-sm">
            M&amp;A Platform
          </span>
        </div>
        <div className="space-y-6 max-w-md">
          <p className="text-2xl font-medium leading-snug tracking-tight">
            Create your first workspace to get started.
          </p>
          <p className="text-sm text-primary-foreground/70 leading-relaxed">
            One workspace per deal or acquisition target. You&apos;ll connect
            accounting, run diligence, and produce investor-grade reports
            against it.
          </p>
        </div>
        <p className="text-xs text-primary-foreground/60">
          © {new Date().getFullYear()} · Secured by Cloudflare &amp; Supabase
        </p>
      </div>

      {/* Right — CTA */}
      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-sm space-y-8 text-center">
          <div className="mx-auto h-12 w-12 rounded-md bg-primary/10 grid place-items-center text-primary">
            <Plus className="h-5 w-5" strokeWidth={1.75} />
          </div>
          <div className="space-y-2">
            <h1 className="text-xl font-semibold tracking-tight">
              Create a workspace
            </h1>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Every deal lives in its own workspace. You can create as many
              as you need and switch between them freely.
            </p>
          </div>
          <CreateCompanyDialog
            trigger={<Button size="lg" className="w-full">Create workspace</Button>}
          />
        </div>
      </div>
    </div>
  )
}
