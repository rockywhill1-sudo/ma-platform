'use server'

import { z } from 'zod'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

const CreateCompanySchema = z.object({
  name: z.string().min(1, 'Name is required').max(200),
  industry: z.string().max(100).optional().or(z.literal('')),
  fiscalYearEndMonth: z.coerce.number().int().min(1).max(12).default(12),
  currency: z
    .string()
    .regex(/^[A-Z]{3}$/, 'Use a 3-letter currency code')
    .default('USD'),
})

function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80)
}

export type CreateCompanyState = {
  error?: string
  fieldErrors?: Record<string, string>
} | null

export async function createCompany(
  _prev: CreateCompanyState,
  formData: FormData,
): Promise<CreateCompanyState> {
  const parsed = CreateCompanySchema.safeParse({
    name: formData.get('name'),
    industry: formData.get('industry'),
    fiscalYearEndMonth: formData.get('fiscalYearEndMonth'),
    currency: formData.get('currency'),
  })

  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {}
    parsed.error.issues.forEach((i) => {
      const key = i.path[0]?.toString() ?? 'form'
      fieldErrors[key] = i.message
    })
    return { error: 'Fix the errors below.', fieldErrors }
  }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return { error: 'Not signed in' }

  // Make slug unique by appending a short suffix if taken
  const baseSlug = slugify(parsed.data.name) || 'company'
  let slug = baseSlug
  let attempts = 0
  while (attempts < 5) {
    const { data: existing } = await supabase
      .from('companies')
      .select('id')
      .eq('slug', slug)
      .maybeSingle()
    if (!existing) break
    slug = `${baseSlug}-${Math.random().toString(36).slice(2, 6)}`
    attempts++
  }

  const { data: company, error: companyError } = await supabase
    .from('companies')
    .insert({
      name: parsed.data.name,
      slug,
      industry: parsed.data.industry || null,
      fiscal_year_end_month: parsed.data.fiscalYearEndMonth,
      currency: parsed.data.currency,
      created_by: user.id,
    })
    .select('id')
    .single()

  if (companyError || !company) {
    return { error: companyError?.message ?? 'Failed to create company' }
  }

  const { error: membershipError } = await supabase
    .from('company_users')
    .insert({
      company_id: company.id,
      user_id: user.id,
      role: 'owner',
      added_by: user.id,
    })

  if (membershipError) {
    return { error: membershipError.message }
  }

  revalidatePath('/', 'layout')
  redirect(`/companies/${company.id}/dashboard`)
}
