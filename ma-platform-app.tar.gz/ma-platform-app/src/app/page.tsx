import { redirect } from 'next/navigation'
import { getCompaniesForCurrentUser } from '@/lib/queries/companies'

export default async function RootPage() {
  const companies = await getCompaniesForCurrentUser()

  if (companies.length === 0) {
    redirect('/companies/new')
  }
  redirect(`/companies/${companies[0].id}/dashboard`)
}
